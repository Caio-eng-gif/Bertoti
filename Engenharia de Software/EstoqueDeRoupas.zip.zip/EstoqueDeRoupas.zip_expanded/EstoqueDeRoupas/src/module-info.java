/**
 * 
 */
/**
 * @author HP
 *
 */
module EstoqueDeRoupas {
	requires java.desktop;
	requires org.junit.jupiter.api;
}